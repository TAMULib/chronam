Formats dates according to the :RFC:`3339`.


